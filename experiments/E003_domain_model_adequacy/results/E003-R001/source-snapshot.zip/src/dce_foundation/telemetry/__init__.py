"""External telemetry adapters."""
